from aiogram.dispatcher.filters.state import State, StatesGroup

class user_solution(StatesGroup):
    solution = State()