#include <iostream>
#include <vector>
#include <cstdlib>
#include <algorithm>

using namespace std;

class Question {
private:
    string text;
    vector<string> options;
    int correctAnswerIndex;

public:
    Question(const string& questionText, const vector<string>& questionOptions, int correctIndex)
        : text(questionText), options(questionOptions), correctAnswerIndex(correctIndex) {}

    const string& getText() const {
        return text;
    }

    const vector<string>& getOptions() const {
        return options;
    }

    int getCorrectAnswerIndex() const {
        return correctAnswerIndex;
    }
};

class Test {
private:
    vector<Question*> questions;

public:
    ~Test() {
        for (Question* question : questions) {
            delete question;
        }
    }

    void addQuestion(Question* question) {
        questions.push_back(question);
    }

    bool isEmpty() const {
        return questions.empty();
    }

    const vector<Question*>& getQuestions() const {
        return questions;
    }
};

void displayMenu() {
    cout << "------ Menu ------" << endl;
    cout << "1. Start the test" << endl;
    cout << "2. Add a question" << endl;
    cout << "3. Exit" << endl;
    cout << "------------------" << endl;
    cout << "Enter your choice: ";
}

int main() {
    // srand(static_cast<unsigned int>(time(0)));

    Test test;

    while (true) {
        displayMenu();

        int choice;
        cin >> choice;
        cin.ignore();

        if (choice == 1) {
            if (test.isEmpty()) {
                cout << "No questions added. Unable to start the test." << endl;
            } else {
                vector<Question*> questions = test.getQuestions();
                random_shuffle(questions.begin(), questions.end());

                int score = 0;

                for (Question* question : questions) {
                    cout << endl;
                    cout << "Question: " << question->getText() << endl;

                    const vector<string>& options = question->getOptions();
                    for (int i = 0; i < options.size(); ++i) {
                        cout << (i + 1) << ". " << options[i] << endl;
                    }

                    cout << "Enter your answer (1-" << options.size() << "): ";
                    int userAnswerIndex;
                    cin >> userAnswerIndex;
                    cin.ignore();

                    if (userAnswerIndex >= 1 && userAnswerIndex <= options.size()) {
                        if (userAnswerIndex == question->getCorrectAnswerIndex()) {
                            cout << "Correct answer!" << endl;
                            ++score;
                        } else {
                            cout << "Incorrect answer!" << endl;
                        }
                    } else {
                        cout << "Invalid answer index." << endl;
                    }
                }

                cout << endl;
                cout << "Test completed." << endl;
                cout << "Score: " << score << "/" << questions.size() << endl;
            }
        } else if (choice == 2) {
            string text;
            cout << "Enter the question: ";
            getline(cin, text);

            int optionCount;
            cout << "Enter the number of options: ";
            cin >> optionCount;
            cin.ignore();

            vector<string> options;
            for (int i = 0; i < optionCount; ++i) {
                string option;
                cout << "Enter option " << (i + 1) << ": ";
                getline(cin, option);
                options.push_back(option);
            }
            int correctAnswerIndex;
            cout << "Enter the index of the correct answer (1-" << optionCount << "): ";
            cin >> correctAnswerIndex;
            cin.ignore();

            Question* question = new Question(text, options, correctAnswerIndex);
            test.addQuestion(question);

            cout << "Question added successfully." << endl;
        } else if (choice == 3) {
            break;
        } else {
            cout << "Invalid choice. Please try again." << endl;
        }

        cout << endl;
    }

    return 0;
}